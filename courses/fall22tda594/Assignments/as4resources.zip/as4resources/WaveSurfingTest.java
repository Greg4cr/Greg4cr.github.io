package test.java;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import main.java.ourrobots.AdvancedRobotMock;
import main.java.ourrobots.ScannedRobotEventMock;
import main.java.ourrobots.WaveSurfing;
import robocode.AdvancedRobot;
import robocode.Bullet;
import robocode.HitByBulletEvent;
import robocode.ScannedRobotEvent;

public class WaveSurfingTest {
	AdvancedRobotMock robot;
	WaveSurfing movement;
	
	@Before
	public void setup() {
		robot = new AdvancedRobotMock();
		movement = new WaveSurfing(robot);
	}
	
	@Test
	public void avoidsWall() {
		
		robot.setY(100);
		// Needs to run move at least twice before being able to react to power drop
		ScannedRobotEvent e = new ScannedRobotEventMock(-Math.PI/2, 400, Math.PI/2, 0, 5.0);
		movement.move(e);
		movement.move(e);
		
		e = new ScannedRobotEventMock(-Math.PI/2, 400, Math.PI/2, 0, 3.0);
		
		movement.move(e);
		
		robot.setY(robot.getBattleFieldHeight() / 2.0);
		
		assertTrue(Math.abs(robot.getHeadingRadians()) > 0.5);

	}
	
	@Test
	public void testRobotDodgeRight() {
		
		Bullet bullet = new Bullet(0, robot.getX(), robot.getY(), 2, "owner1", "waveSurfer", true, 1);
		
		HitByBulletEvent bulletEvent = new HitByBulletEvent(0, bullet);
		
		//Mock enemy robot position as stationary 200 units below positioned slightly to the left of the waveSurfing robot
		ScannedRobotEventMock event = new ScannedRobotEventMock((Math.PI)*190.0/180.0,0,0,0, 5);
		
		// Needs to run move at least twice before being able to react to power drop
		movement.move(event);
		movement.move(event);
		
		//Mock enemy robot with a decrease in energy level at the same position as before
		event = new ScannedRobotEventMock((Math.PI)*190.0/180.0,0,0,0, 3);
		
		movement.move(event);
		
		//Make the robot get hit by a bullet in order for the robot to store information to use when dodging bullets.
		movement.onHitByBullet(bulletEvent);
		
		event = new ScannedRobotEventMock((Math.PI)*190.0/180.0,50,0,0, 3);
		
		// Needs to run move at least twice before being able to react to power drop
		movement.move(event);
		movement.move(event);
		
		
		//Mock enemy robot with a decrease in energy level at the same position as before
		event = new ScannedRobotEventMock((Math.PI)*190.0/180.0,50,0,0, 1);
		
		for(int i = 0; i < 5; i++) {
			movement.move(event);
			robot.setTime(robot.getTime() + 1);
		}
		

		//Checking if the x coordinate of the robot is bigger than the starting x coordinate. This is enough to know that the robot has dodged to the right.
		assertTrue(400 < robot.getX());
	}
	
	
	@Test
	public void testRobotDodgeLeft() {
		

		Bullet bullet = new Bullet(0, robot.getX(), robot.getY(), 2, "owner1", "waveSurfer", true, 1);
		
	
		HitByBulletEvent bulletEvent = new HitByBulletEvent(0, bullet);
		
		//Mock enemy robot position as stationary 200 units below positioned slightly to the right of the waveSurfing robot
		ScannedRobotEventMock event = new ScannedRobotEventMock((Math.PI)*170.0/180.0,0,0,0, 5);
		
		// Needs to run move at least twice before being able to react to power drop
		movement.move(event);
		movement.move(event);
		
		//Mock enemy robot with a decrease in energy level at the same position as before
		event = new ScannedRobotEventMock((Math.PI)*170.0/180.0,0,0,0, 3);
		
		movement.move(event);
		
		//Make the robot get hit by a bullet in order for the robot to store information to use when dodging bullets.
		movement.onHitByBullet(bulletEvent);
		
		event = new ScannedRobotEventMock((Math.PI)*170.0/180.0,50,0,0, 3);
		
		// Needs to run move at least twice before being able to react to power drop
		movement.move(event);
		movement.move(event);
		
		
		//Mock enemy robot with a decrease in energy level at the same position as before
		event = new ScannedRobotEventMock((Math.PI)*170.0/180.0,50,0,0, 1);
		
		for(int i = 0; i < 5; i++) {
			movement.move(event);
			robot.setTime(robot.getTime() + 1);
		}
		
		
		//Checking if the x coordinate of the robot is smaller than the starting x coordinate. This is enough to know that the robot has dodged to the left.
		assertTrue(400 > robot.getX());
	}
	

	@Test
	public void noIncomingBullets() {
		ScannedRobotEvent event1 = new ScannedRobotEventMock(0, 20, Math.PI/2, 0, 3);
		ScannedRobotEvent event2 = new ScannedRobotEventMock(0, 20, Math.PI/2, 0, 3);
		
		assertEquals(robot.getX(), 400, 0.01);
		assertEquals(robot.getY(), 300, 0.01);

		//Enemy robot scanned twice, no power drop detected between scans
		movement.move(event1);
		movement.move(event2);
		
		assertEquals(robot.getX(), 400, 0.01);
		assertEquals(robot.getY(), 300, 0.01);

	}
	
	@Test
	public void logBulletHit() {
		
		Bullet bullet = new Bullet(0, robot.getX(), robot.getY(), 2, "owner1", "waveSurfer", true, 1);
		
		
		HitByBulletEvent bulletEvent = new HitByBulletEvent(0, bullet);
		
		//Mock enemy robot position as stationary 20 units above robot
		ScannedRobotEventMock event = new ScannedRobotEventMock(0,20,0,0, 5);
		
		// Needs to run move at least twice before being able to react to power drop
		movement.move(event);
		movement.move(event);
		
		//Mock enemy robot with a decrease in energy level at the same position as before
		event = new ScannedRobotEventMock(0,20,0,0, 3);
		
		movement.move(event);
		
		assertTrue(movement.getLog()[23] == 0);
		assertTrue(movement.getLog()[22] == 0);
		assertTrue(movement.getLog()[21] == 0);

		//Make the robot get hit by a bullet in order for the robot to stores correct information in log
		movement.onHitByBullet(bulletEvent);
		
		assertTrue(movement.getLog()[23] == 1);
		
		//assert that bin smoothing of logged data is working as expected
		assertTrue(movement.getLog()[22] == 0.5);
        assertTrue(movement.getLog()[21] == 0.2);
		
	}
	
}
